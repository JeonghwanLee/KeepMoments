package com.example.keepmoments;

import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;

import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * A simple {@link Fragment} subclass.
 */
public class VideoFeedFragment extends Fragment {
    private static final String TAG = "VideoFeedFragment";

    private View mView;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mRecyclerviewAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private StorageReference mStorageRef;

    private SwipeRefreshLayout mRefreshLayout;
    private ArrayList<VideoRefItem> mVideoRefItems; // This is the list of current video files on Firebase
    public ArrayList<VideoRefItem> mNewVideoItems; // This items are updated when new videos are uploaded to Firebase passed from MainActivity
    public int mPrevVideoItemSize; // Track the number of newly uploaded videos since the app launched

    public VideoFeedFragment(StorageReference storageReference, ArrayList<VideoRefItem> newVideoItems) {
        mStorageRef = storageReference;
        mVideoRefItems = new ArrayList<>();
        mNewVideoItems = newVideoItems;
        mPrevVideoItemSize = 0;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_video_feed, container, false);
        // Set refresh layout to update mRecyclerviewAdapter when there are uploaded videos
        mRefreshLayout = mView.findViewById(R.id.refresh_layout);
        mRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // OnRefresh is called when the user swiped down on the Video Feed tab
                mRefreshLayout.setRefreshing(true);
                // Add a uploaded video in NewVideoItems to mVideoRefItems and notify it to  mRecyclerviewAdapter
                if (!mNewVideoItems.isEmpty() && mNewVideoItems.size() > mPrevVideoItemSize) {
                    mPrevVideoItemSize = mNewVideoItems.size();
                    mVideoRefItems.add(mNewVideoItems.get(mNewVideoItems.size() - 1));
                    sortVideoRefItems();
                    mRecyclerviewAdapter.notifyDataSetChanged();
                }

                mRefreshLayout.setRefreshing(false);
            }
        });

        // Arrenge Video Feed Fragment initially
        arrangeVideoFeedFragment();
        return mView;
    }

    private void arrangeVideoFeedFragment() {
        mRecyclerView = mView.findViewById(R.id.recycler_view);
        mLayoutManager = new LinearLayoutManager(getActivity());
        // Update Video items from Firebase
        updateVideoRefItems();
        mRecyclerviewAdapter = new RecyclerViewAdapter(mVideoRefItems);

        // Set layout manager and adpater for mRecyclerView
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mRecyclerviewAdapter);
    }

    private void updateVideoRefItems() {
        // Get a reference of 'videos' from Firebase
        StorageReference listRef = mStorageRef.child("videos");

        // Get the current list of the videos uploaded to Firebase storage
        listRef.listAll()
                .addOnSuccessListener(new OnSuccessListener<ListResult>() {
                    @Override
                    public void onSuccess(ListResult listResult) {
                        for (StorageReference item : listResult.getItems()) {
                            final String temp = item.getName();
                            // Get download url for each video
                            item.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    addVideoRefItems(temp, uri.toString());
                                }
                            });
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Failed to get the list of video files from Firebase
                        Toast.makeText(getActivity(), "Failed to get the list from Firebase.\n" + e.getMessage() , Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void addVideoRefItems(String fileName, String fileUrl) {
        // Create VideoRefItem using file name and url from Firebase and add it to mVideoRefItems
        VideoRefItem videoRefItem =  new VideoRefItem(fileName, fileUrl);
        mVideoRefItems.add(videoRefItem);

        // Sort mVideoRefItems by descending order by date
        sortVideoRefItems();
    }

    private void sortVideoRefItems() {
        // Sort mVideoRefItems by descending order by date with format "MM-dd-yyyy '@'hh:mm:ss"
        Collections.sort(mVideoRefItems, new Comparator<VideoRefItem>() {
            DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy '@'hh:mm:ss");
            @Override
            public int compare(VideoRefItem o1, VideoRefItem o2) {
                try {
                    return dateFormat.parse(o1.getVideoRef()).compareTo(dateFormat.parse(o2.getVideoRef()));
                } catch (java.text.ParseException e) {
                    throw new IllegalArgumentException(e);
                }
            }
        });

        Collections.reverse(mVideoRefItems);
    }
}
