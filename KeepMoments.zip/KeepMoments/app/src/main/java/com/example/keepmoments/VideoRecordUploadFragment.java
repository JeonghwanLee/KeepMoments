package com.example.keepmoments;

import android.content.Intent;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;

import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;


import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.OnProgressListener;

import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.Date;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 */
public class VideoRecordUploadFragment extends Fragment {
    private static final String TAG = "VideoRecordUploadFragment";
    private static final int REQUEST_CODE = 101;

    private View mView;
    private Uri mVideoUri;

    private StorageReference mStorageRef;
    private Button mRecordBtn;
    private Button mUploadBtn;

    public ArrayList<VideoRefItem> mNewVideoItems; // This items are updated when new video

    public VideoRecordUploadFragment(StorageReference storageReference, ArrayList<VideoRefItem> videoRefItems) {
        // Construct VideoRecordUploadFragment with storageReference and videoRefItems passed from MainActivity
        mStorageRef = storageReference;
        mNewVideoItems = videoRefItems;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment and return the view
        mView =  inflater.inflate(R.layout.fragment_video_record_upload, container, false);

        // Add onClickListener to Record button
        mRecordBtn = mView.findViewById(R.id.btnRecord);
        mRecordBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                record();
            }
        });

        // Add onClickListener to Upload button
        mUploadBtn = mView.findViewById(R.id.btnUpload);
        mUploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                upload();
            }
        });

        return mView;
    }

    private void record() {
        // Record a video using a deafult camera app accessed by MediaStore
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(intent, REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Save a video uri saved locally
        mVideoUri = data.getData();

        //  Display a Toast message depending on the result code
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(getActivity(), "Video Saved to:\n" + mVideoUri, Toast.LENGTH_SHORT).show();
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(getActivity(), "Video Recording Cancelled", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Failed Recording Video", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void upload() {
        //  Only upload when mVideoUri is not null
        if (mVideoUri != null) {
            DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy '@'hh:mm:ss");
            final String gmtTime = dateFormat.format(new Date());

            // Get Firebase storage reference to use for uploading
            final StorageReference ref = mStorageRef.child("videos/" + gmtTime);

            // Upload the recorded video to Firebase Storage
            UploadTask uploadTask  = ref.putFile(mVideoUri);

            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getActivity(), "Upload Failed: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            }).addOnSuccessListener(
                    new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            // Get download url of Firebase Storage for the uploaded file
                            ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    // Update a progress value to modify the length of the progress bar
                                    addFileInfoToLocal(gmtTime, uri.toString());
                                }
                            });
                        }
                    }).addOnProgressListener(
                    new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                            // Update a progress bar as the upload progress
                            updateProgress(taskSnapshot);
                        }
                    });
        } else {
            Toast.makeText(getActivity(), "Nothing to Upload", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateProgress(UploadTask.TaskSnapshot taskSnapshot) {
        @SuppressWarnings("VisibleForTests")
        long fileSize = taskSnapshot.getTotalByteCount();

        @SuppressWarnings("VisibleForTests")
        long uploadBytes = taskSnapshot.getBytesTransferred();

        long progress = (100 * uploadBytes) / fileSize;
        // Update a progress value to modify the length of the progress bar
        ProgressBar progressBar = mView.findViewById(R.id.progressBar);
        progressBar.setProgress((int) progress);
        Toast.makeText(getActivity(), (int) progress + "%", Toast.LENGTH_SHORT).show();
    }

    private void addFileInfoToLocal(String gmtTime, String uri) {
        Toast.makeText(getActivity(), "Successfully Uploaded", Toast.LENGTH_LONG).show();
        // Add new video information to NewVideoItems
        mNewVideoItems.add(new VideoRefItem(gmtTime, uri));
        mVideoUri = null;
    }
}