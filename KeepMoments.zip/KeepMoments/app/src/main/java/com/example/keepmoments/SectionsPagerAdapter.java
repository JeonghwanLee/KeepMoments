package com.example.keepmoments;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class SectionsPagerAdapter extends FragmentPagerAdapter {
    private static final String TAG = "SectionsPagerAdapter";

    private final List<Fragment> mFragementList = new ArrayList<>(); // Store each fragment for pager adapter
    private final List<String> mFragementTitleList = new ArrayList<>(); // Store each fragment's title

    public SectionsPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    // Called when each fragment is constructed from MainActivity
    public void addFragment(Fragment fragment, String title) {
        mFragementList.add(fragment);
        mFragementTitleList.add(title);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mFragementTitleList.get(position);
    }

    @Override
    public Fragment getItem(int position) {
        return mFragementList.get(position);
    }

    @Override
    public int getCount() {
        return mFragementTitleList.size();
    }
}
