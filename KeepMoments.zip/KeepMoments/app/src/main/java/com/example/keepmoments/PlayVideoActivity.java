package com.example.keepmoments;

import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PlayVideoActivity extends AppCompatActivity {
    private static final String TAG = "PlayVideoActivity";

    private VideoView mVideoView;
    private MediaController mMediaController;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_play);
        mVideoView = findViewById(R.id.video_view);

        Bundle bundle = getIntent().getExtras();
        assert bundle != null;
        String uri = bundle.getString("uri");

        mMediaController = new MediaController(this);
        mMediaController.setAnchorView(mVideoView);

        mVideoView.setVideoPath(uri);
        mVideoView.setMediaController(mMediaController);
        mVideoView.requestFocus();
        mVideoView.start();
    }
}
