package com.example.keepmoments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private static final String TAG = "RecyclerViewAdapter";

    private ArrayList<VideoRefItem> mVideoRefItems; // List of videos passed from Video Feed Fragment

    // ViewHolder is a container to store each video item and to be displayed in RecyclerView
    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView mVideoRef;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mVideoRef = itemView.findViewById(R.id.video_ref);
            // Set OnClickListener to open Play Video activity to play the clicked video item
            mVideoRef.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    streamVideo(view);
                }
            });
        }

        private void streamVideo(View view) {
            String fileName = mVideoRef.getText().toString();
            String fileUrl = null;
            Context  context = view.getContext();

            // Get a video url matched with the video name
            for (VideoRefItem videoRefItem : mVideoRefItems) {
                if (videoRefItem.getVideoRef().equals(fileName)) {
                    fileUrl = videoRefItem.getVideoUrl();
                }
            }

            // Set Intent and Bundle to pass to Play Video Activity
            Intent intent = new Intent(context, PlayVideoActivity.class);
            Bundle bundle = new Bundle();
            bundle.putString("uri", fileUrl);
            intent.putExtras(bundle);

            // Start Play Video Activity to stream the selcected video
            context.startActivity(intent);
        }
    }

    public RecyclerViewAdapter(ArrayList<VideoRefItem> videoRefItems) {
        // Get the video items passed from Video Feed Fragment
        mVideoRefItems = videoRefItems;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Return each view holder of a video item to display on Recycler View
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_video_feed_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Bind the view holder with video item
        VideoRefItem currentItem = mVideoRefItems.get(position);
        holder.mVideoRef.setText(currentItem.getVideoRef());
    }

    @Override
    public int getItemCount() {
        return mVideoRefItems.size();
    }
}
