package com.example.keepmoments;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private SectionsPagerAdapter mSectionsPageAdaper;
    private ViewPager mViewPager;

    private StorageReference mStorageRef;
    static public ArrayList<VideoRefItem> mNewVideoItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Open a loading page when the app is launched
        Intent intent = new Intent(this, LoadingActivity.class);
        startActivity(intent);

        mStorageRef = FirebaseStorage.getInstance().getReference();

        mSectionsPageAdaper = new SectionsPagerAdapter(getSupportFragmentManager());
        mViewPager = findViewById(R.id.view_pager);
        setUpViewPager(mViewPager);

        TabLayout tabLayout = findViewById(R.id.tabs);
        // Set up View Pager for teb layout
        tabLayout.setupWithViewPager(mViewPager);
    }

    private void setUpViewPager(ViewPager viewPager) {
        SectionsPagerAdapter adapter = new SectionsPagerAdapter(getSupportFragmentManager());
        // Add VideoRecordUpload fragment and VideoFeed fragment to pager adapter.
        adapter.addFragment(new VideoRecordUploadFragment(mStorageRef, mNewVideoItems), "RECORD");
        adapter.addFragment(new VideoFeedFragment(mStorageRef, mNewVideoItems), "FEED");
        viewPager.setAdapter(adapter);
    }
}