package com.example.keepmoments;

public class VideoRefItem {
    private static final String TAG = "VideoRefItem";

    public String mVideoRefString; // Represents a video file name
    public String mVideoUrl; // Represents a video url

    public VideoRefItem(String videoRef, String url) {
        mVideoRefString = videoRef;
        mVideoUrl = url;
    }

    public String getVideoRef() {
        return mVideoRefString;
    }
    public String getVideoUrl() {
        return mVideoUrl;
    }
}
